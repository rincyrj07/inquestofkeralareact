import React from 'react'
import { Button, Card, Carousel, Col, Container, Row } from 'react-bootstrap';
<link rel="stylesheet" href="./bootstrap.min (2).css"></link>

function Home() {
    return (
        <Container>
            <Row>
                <Col className='py-3'>
                <Carousel data-bs-theme="dark">
      <Carousel.Item>
        <img
          className="d-block w-100"
          src=" https://wandertrust.in/wp-content/uploads/2021/04/maxresdefault.jpg"
          alt="First slide"
        />
        <Carousel.Caption>
          <h5>First slide label</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src=" https://www.ekeralatourism.net/wp-content/uploads/2015/12/Varkala-Beach.png"
          alt="Second slide"
        />
        <Carousel.Caption>
          <h5>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src=" https://www.mapsofindia.com/maps/kerala/images/kerala.jpg"
          alt="Third slide"
        />
        <Carousel.Caption>
          <h5>Third slide label</h5>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
                </Col>
            </Row>
           
            <Row>
                <Col className='py-3' md={3} >
                    <Card>
                        <Card.Img variant="top" src="https://www.keralatourism.org/images/yatri-nivas.jpg" />
                        <Card.Body>
                            <Card.Title>YATHRI NIVAS</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button variant="dark">Click Here</Button>
                        </Card.Body>
                    </Card>
                </Col>
                <Col className='py-3' md={3} >
                    <Card>
                        <Card.Img variant="top" src="https://www.keralatourism.org/images/campaign-video/E-brochure1.jpg" />
                        <Card.Body>
                            <Card.Title>Virtual Travel Assistant</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button variant="dark">Click Here</Button>
                        </Card.Body>
                    </Card>
                </Col>
                <Col className='py-3' md={3} >
                    <Card>
                        <Card.Img variant="top" src="https://www.keralatourism.org/images/campaign-video/App.jpg" />
                        <Card.Body>
                            <Card.Title>Best Kerala Travel App</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button variant="dark">Click Here</Button>
                        </Card.Body>
                    </Card>
                </Col>
                <Col className='py-3' md={3} >
                    <Card>
                        <Card.Img variant="top" src="https://www.keralatourism.org/images/campaign-video/Youtbe-p.jpg" />
                        <Card.Body>
                            <Card.Title>Campaign-video</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button variant="dark">Click Here</Button>
                        </Card.Body>
                    </Card>
                </Col>

            </Row>

            

        </Container>
    )
}

export default Home